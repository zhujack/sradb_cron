-- phpMyAdmin SQL Dump
-- version 3.5.4
-- http://www.phpmyadmin.net
--
-- Host: sartre.nci.nih.gov
-- Generation Time: Dec 01, 2023 at 07:52 AM
-- Server version: 5.1.73-log
-- PHP Version: 5.3.19

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `sra`
--

-- --------------------------------------------------------

--
-- Table structure for table `col_desc`
--

CREATE TABLE IF NOT EXISTS `col_desc` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `table_name` varchar(20) DEFAULT NULL,
  `field_name` varchar(50) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `description` text,
  `value_list` text,
  `sradb_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`),
  FULLTEXT KEY `description` (`description`),
  FULLTEXT KEY `value` (`value_list`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=130 ;

-- --------------------------------------------------------

--
-- Table structure for table `data_block`
--

CREATE TABLE IF NOT EXISTS `data_block` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `run_accession` varchar(50) DEFAULT NULL,
  `sector` int(2) DEFAULT NULL,
  `region` int(10) DEFAULT NULL,
  `files` text,
  `sradb_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`),
  KEY `run_accession` (`run_accession`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `experiment`
--

CREATE TABLE IF NOT EXISTS `experiment` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `bamFile` varchar(255) DEFAULT NULL,
  `fastqFTP` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `accession` varchar(50) NOT NULL,
  `broker_name` varchar(255) DEFAULT NULL,
  `center_name` text,
  `title` text,
  `study_name` varchar(255) DEFAULT NULL,
  `study_accession` varchar(50) DEFAULT NULL,
  `design_description` mediumtext,
  `sample_name` varchar(255) DEFAULT NULL,
  `sample_accession` varchar(50) DEFAULT NULL,
  `sample_member` text,
  `library_name` text,
  `library_strategy` varchar(255) DEFAULT NULL,
  `library_source` varchar(255) DEFAULT NULL,
  `library_selection` varchar(255) DEFAULT NULL,
  `library_layout` varchar(255) DEFAULT NULL,
  `targeted_loci` text,
  `library_construction_protocol` text,
  `spot_length` int(3) DEFAULT NULL,
  `adapter_spec` text,
  `read_spec` text,
  `platform` varchar(255) DEFAULT NULL,
  `instrument_model` varchar(255) DEFAULT NULL,
  `platform_parameters` text,
  `sequence_space` varchar(255) DEFAULT NULL,
  `base_caller` varchar(255) DEFAULT NULL,
  `quality_scorer` varchar(255) DEFAULT NULL,
  `number_of_levels` int(5) DEFAULT NULL,
  `multiplier` varchar(255) DEFAULT NULL,
  `qtype` varchar(50) DEFAULT NULL,
  `sra_link` text,
  `url_link` text,
  `xref_link` text,
  `entrez_link` text,
  `ddbj_link` text,
  `ena_link` text,
  `experiment_attribute` text,
  `submission_accession` varchar(50) DEFAULT NULL,
  `sradb_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `accession` (`accession`),
  KEY `study_accession` (`study_accession`),
  KEY `sample_accession` (`sample_accession`),
  KEY `submission_accession` (`submission_accession`),
  KEY `submission_accession_2` (`submission_accession`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13453442 ;

-- --------------------------------------------------------

--
-- Table structure for table `fastq`
--

CREATE TABLE IF NOT EXISTS `fastq` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `RUN_ID` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `RUN_ALIAS` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `EXPERIMENT_ID` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `EXPERIMENT_ALIAS` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `SAMPLE_ID` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `SAMPLE_ALIAS` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `STUDY_ID` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `STUDY_ALIAS` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `LIBRARY_LAYOUT` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `INSTRUMENT_PLATFORM` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `STUDY_TYPE` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `FASTQ_FILES` int(2) DEFAULT NULL,
  `TAX_ID` int(10) DEFAULT NULL,
  `SCIENTIFIC_NAME` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `COMMON_NAME` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `fastq_old`
--

CREATE TABLE IF NOT EXISTS `fastq_old` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `accession` varchar(20) NOT NULL,
  `file_name` varchar(50) NOT NULL,
  `md5` varchar(50) NOT NULL,
  `bytes` bigint(15) NOT NULL,
  `audit_time` datetime NOT NULL,
  `sradb_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `metaInfo`
--

CREATE TABLE IF NOT EXISTS `metaInfo` (
  `name` varchar(50) DEFAULT NULL,
  `value` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `request`
--

CREATE TABLE IF NOT EXISTS `request` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `lab` varchar(150) DEFAULT NULL,
  `message` text,
  `status` enum('Submitted','In queue','Started','Completed','Aborted','Failed') NOT NULL,
  `accessions` text NOT NULL,
  `commands` text NOT NULL,
  `date_submitted` datetime NOT NULL,
  `sradb_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

-- --------------------------------------------------------

--
-- Table structure for table `run`
--

CREATE TABLE IF NOT EXISTS `run` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `bamFile` varchar(255) DEFAULT NULL,
  `alias` text,
  `accession` varchar(50) NOT NULL,
  `broker_name` text,
  `instrument_name` varchar(255) DEFAULT NULL,
  `run_date` datetime DEFAULT NULL,
  `run_file` text,
  `run_center` varchar(255) DEFAULT NULL,
  `total_data_blocks` int(10) DEFAULT NULL,
  `experiment_accession` varchar(255) DEFAULT NULL,
  `experiment_name` varchar(255) DEFAULT NULL,
  `sra_link` text,
  `url_link` text,
  `xref_link` text,
  `entrez_link` text,
  `ddbj_link` text,
  `ena_link` text,
  `run_attribute` text,
  `submission_accession` varchar(50) DEFAULT NULL,
  `sradb_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `accession` (`accession`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14773193 ;

-- --------------------------------------------------------

--
-- Table structure for table `sample`
--

CREATE TABLE IF NOT EXISTS `sample` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `alias` varchar(255) DEFAULT NULL,
  `accession` varchar(50) NOT NULL,
  `broker_name` varchar(255) DEFAULT NULL,
  `center_name` varchar(255) DEFAULT NULL,
  `taxon_id` int(10) DEFAULT NULL,
  `scientific_name` varchar(255) DEFAULT NULL,
  `common_name` text,
  `anonymized_name` varchar(255) DEFAULT NULL,
  `individual_name` varchar(255) DEFAULT NULL,
  `description` text,
  `sra_link` text,
  `url_link` text,
  `xref_link` text,
  `entrez_link` text,
  `ddbj_link` text,
  `ena_link` text,
  `sample_attribute` text,
  `submission_accession` varchar(50) DEFAULT NULL,
  `sradb_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `accession` (`accession`),
  KEY `submission_accession` (`submission_accession`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12640224 ;

-- --------------------------------------------------------

--
-- Table structure for table `sra`
--

CREATE TABLE IF NOT EXISTS `sra` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `SRR_bamFile` varchar(255) DEFAULT NULL,
  `SRX_bamFile` varchar(255) DEFAULT NULL,
  `SRX_fastqFTP` varchar(50) DEFAULT NULL,
  `run_ID` int(10) unsigned DEFAULT '0',
  `run_alias` varchar(255) DEFAULT NULL,
  `run_accession` varchar(50) DEFAULT NULL,
  `run_date` date DEFAULT NULL,
  `updated_date` date DEFAULT NULL,
  `spots` bigint(15) DEFAULT NULL,
  `bases` bigint(15) DEFAULT NULL,
  `run_center` varchar(255) DEFAULT NULL,
  `experiment_name` varchar(255) DEFAULT NULL,
  `run_url_link` text,
  `run_entrez_link` text,
  `run_attribute` text,
  `experiment_ID` int(10) unsigned DEFAULT '0',
  `experiment_alias` varchar(255) DEFAULT NULL,
  `experiment_accession` varchar(50) DEFAULT NULL,
  `experiment_title` varchar(255) DEFAULT NULL,
  `study_name` varchar(255) DEFAULT NULL,
  `sample_name` varchar(255) DEFAULT NULL,
  `design_description` text,
  `library_name` varchar(255) DEFAULT NULL,
  `library_strategy` varchar(255) DEFAULT NULL,
  `library_source` varchar(255) DEFAULT NULL,
  `library_selection` varchar(255) DEFAULT NULL,
  `library_layout` varchar(255) DEFAULT NULL,
  `library_construction_protocol` text,
  `adapter_spec` varchar(255) DEFAULT NULL,
  `read_spec` text,
  `platform` varchar(255) DEFAULT NULL,
  `instrument_model` varchar(255) DEFAULT NULL,
  `instrument_name` varchar(255) DEFAULT NULL,
  `platform_parameters` text,
  `sequence_space` varchar(255) DEFAULT NULL,
  `base_caller` varchar(255) DEFAULT NULL,
  `quality_scorer` varchar(255) DEFAULT NULL,
  `number_of_levels` int(5) DEFAULT NULL,
  `multiplier` varchar(255) DEFAULT NULL,
  `qtype` varchar(50) DEFAULT NULL,
  `experiment_url_link` text,
  `experiment_entrez_link` text,
  `experiment_attribute` text,
  `sample_ID` int(10) unsigned DEFAULT '0',
  `sample_alias` varchar(255) DEFAULT NULL,
  `sample_accession` varchar(50) DEFAULT NULL,
  `taxon_id` int(10) DEFAULT NULL,
  `common_name` varchar(255) DEFAULT NULL,
  `anonymized_name` varchar(255) DEFAULT NULL,
  `individual_name` varchar(255) DEFAULT NULL,
  `description` text,
  `sample_url_link` text,
  `sample_entrez_link` text,
  `sample_attribute` text,
  `study_ID` int(10) unsigned DEFAULT '0',
  `study_alias` varchar(255) DEFAULT NULL,
  `study_accession` varchar(50) DEFAULT NULL,
  `study_title` varchar(255) DEFAULT NULL,
  `study_type` varchar(255) DEFAULT NULL,
  `study_abstract` text,
  `center_project_name` varchar(255) DEFAULT NULL,
  `study_description` text,
  `study_url_link` text,
  `study_entrez_link` text,
  `study_attribute` text,
  `related_studies` text,
  `primary_study` varchar(10) DEFAULT NULL,
  `submission_ID` int(10) unsigned NOT NULL DEFAULT '0',
  `submission_accession` varchar(50) DEFAULT NULL,
  `submission_comment` text,
  `submission_center` varchar(255) DEFAULT NULL,
  `submission_lab` varchar(255) DEFAULT NULL,
  `submission_date` date DEFAULT NULL,
  `sradb_updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=114510705 ;

-- --------------------------------------------------------

--
-- Table structure for table `SRA_Accessions`
--

CREATE TABLE IF NOT EXISTS `SRA_Accessions` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Accession` varchar(11) DEFAULT NULL,
  `Submission` varchar(10) DEFAULT NULL,
  `Status` varchar(15) DEFAULT NULL,
  `Updated` varchar(10) DEFAULT NULL,
  `Published` varchar(10) DEFAULT NULL,
  `Received` varchar(10) DEFAULT NULL,
  `Type` varchar(15) DEFAULT NULL,
  `Center` varchar(20) DEFAULT NULL,
  `Visibility` varchar(10) DEFAULT NULL,
  `Alias` varchar(150) DEFAULT NULL,
  `Experiment` varchar(10) DEFAULT NULL,
  `Sample` varchar(10) DEFAULT NULL,
  `Study` varchar(10) DEFAULT NULL,
  `Loaded` varchar(10) DEFAULT NULL,
  `Spots` bigint(15) DEFAULT NULL,
  `Bases` bigint(15) DEFAULT NULL,
  `Md5sum` varchar(40) DEFAULT NULL,
  `sradb_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1389295280 ;

-- --------------------------------------------------------

--
-- Table structure for table `SRA_Run_Members`
--

CREATE TABLE IF NOT EXISTS `SRA_Run_Members` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Run` varchar(11) DEFAULT NULL,
  `Member_Name` varchar(100) DEFAULT NULL,
  `Experiment` varchar(10) DEFAULT NULL,
  `Sample` varchar(10) DEFAULT NULL,
  `Study` varchar(10) DEFAULT NULL,
  `Spots` int(10) DEFAULT NULL,
  `Bases` bigint(15) DEFAULT NULL,
  `Status` varchar(20) DEFAULT NULL,
  `sradb_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1910553017 ;

-- --------------------------------------------------------

--
-- Table structure for table `study`
--

CREATE TABLE IF NOT EXISTS `study` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `alias` mediumtext,
  `accession` varchar(50) NOT NULL,
  `study_title` text,
  `study_type` varchar(255) DEFAULT NULL,
  `study_abstract` text,
  `broker_name` varchar(100) DEFAULT NULL,
  `center_name` text,
  `center_project_name` text,
  `study_description` text,
  `related_studies` text,
  `primary_study` varchar(10) DEFAULT NULL,
  `sra_link` text,
  `url_link` text,
  `xref_link` mediumtext,
  `entrez_link` text,
  `ddbj_link` text,
  `ena_link` text,
  `study_attribute` text,
  `submission_accession` varchar(50) DEFAULT NULL,
  `sradb_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `accession` (`accession`),
  KEY `submission_accession` (`submission_accession`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=335942 ;

-- --------------------------------------------------------

--
-- Table structure for table `submission`
--

CREATE TABLE IF NOT EXISTS `submission` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `alias` varchar(255) DEFAULT NULL,
  `accession` varchar(50) NOT NULL,
  `submission_comment` text,
  `files` text,
  `broker_name` varchar(255) DEFAULT NULL,
  `center_name` text,
  `lab_name` varchar(250) DEFAULT NULL,
  `submission_date` date DEFAULT NULL,
  `sra_link` text,
  `url_link` text,
  `xref_link` mediumtext,
  `entrez_link` text,
  `ddbj_link` text,
  `ena_link` text,
  `submission_attribute` text,
  `sradb_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `accession` (`accession`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4340862 ;
